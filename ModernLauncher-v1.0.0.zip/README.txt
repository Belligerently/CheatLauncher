ModernLauncher v1.0.0 - Open Source

A modern application launcher for executable files.
Run ModernLauncher.exe to start the application.

Features:
- Launch .exe files from the Apps folder
- Search and filter applications
- Favorite applications for quick access
- Modern UI with dark theme

This is open source software.
